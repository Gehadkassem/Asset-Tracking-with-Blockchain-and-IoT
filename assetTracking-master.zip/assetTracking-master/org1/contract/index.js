/*
SPDX-License-Identifier: Apache-2.0
*/

'use strict';

const assetContract = require('./lib/assetcontract.js');
module.exports.contracts = [assetContract];